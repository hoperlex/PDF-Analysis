# Document: encrypted.pdf

Path: Синтетический набор / [АР] Архитектурные решения / encrypted

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_c9d4973893b387c2e01be7b15881a928

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/Lv5xrsujK6a1RdF7d0QV)

Синтетическая негативная фикстура: зашифрованный документ.
Файл защищён паролем и должен быть отклонён явно.

## Page 2

### BLOCK #2 [TEXT]: blk_a56eebe5f174ed36b66d85fe523c8919

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/CieuMIJqhnU_CoUDh9oS)

Страница 2. Текстовый слой присутствует, но недоступен без пароля.
Нарушено единственное правило: файл зашифрован.
