# Document: image_only_with_block.pdf

Path: Синтетический набор / [АР] Архитектурные решения / image_only_with_block

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_07785ff05dc8b48085397f280fd6e6a8

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/xa5VDTl3Uuo_OEd4msAK)

Синтетический распознанный текст страницы 1.
Страница не имеет текстового слоя; текст получен только из блока портала.

## Page 2

### BLOCK #2 [TEXT]: blk_291113d5bf6891d0b1517cbdeea6d10b

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/pME7cD5Am41pJwewHMH9)

Синтетический распознанный текст страницы 2.
Страница не имеет текстового слоя; текст получен только из блока портала.
