# Document: ar_v2_05.pdf

Path: Синтетический набор / [АР] Архитектурные решения / ar_v2_05

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_679f3ae4f25c4db0613ad7bbe32809c9

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/SL4K3A1HFegcBjrW_p_v)

Синтетический комплект ar_v2_05.
Лист АР-01: текст проекта.
Действующая ведомость дверей: материал TBD.
Фасад южный: цвет RAL 9010.
Северный фасад кирпич; южный фасад штукатурка.

## Page 2

### BLOCK #2 [TEXT]: blk_1427a858cceb2557494f4bcb369e2f60

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/8SsbZ5ts6zq5mgrRPpTz)

Синтетический комплект ar_v2_05.
Лист АР-02: текст проекта.
Ведомость отделки южного фасада: цвет RAL 7016.
