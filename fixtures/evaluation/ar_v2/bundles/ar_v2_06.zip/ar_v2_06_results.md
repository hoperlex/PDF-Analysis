# Document: ar_v2_06.pdf

Path: Синтетический набор / [АР] Архитектурные решения / ar_v2_06

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_b1522ca4bc0b2c73727e5ad2a9d8192b

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/rkXCVPGgBq5eB7ai2bWa)

Синтетический комплект ar_v2_06.
Лист АР-01: текст проекта.
Действующая выноска: узел примыкания не определено.
План кровли: уклон зоны А равен 2 процента.
Кровля, зона А: уклон 2 процента; зона Б: 5 процентов.

## Page 2

### BLOCK #2 [TEXT]: blk_3d36af8ae3a1d0c01baa25844f090243

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/RA2nnLTk1-PhRwYrlPSr)

Синтетический комплект ar_v2_06.
Лист АР-02: текст проекта.
Примечание к кровле: уклон зоны А равен 5 процентов.
