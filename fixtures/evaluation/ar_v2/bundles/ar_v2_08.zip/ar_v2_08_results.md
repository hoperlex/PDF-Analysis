# Document: ar_v2_08.pdf

Path: Синтетический набор / [АР] Архитектурные решения / ar_v2_08

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_4cbb5d433d06717c7e5251264c4f5f36

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/01yIiLoj2N_IL35HwAAx)

Синтетический комплект ar_v2_08.
Лист АР-01: текст проекта.
Разрез: высота этажа 2 равна 3,30 м.
Деталь кровли: парапет 600 мм.

## Page 2

### BLOCK #2 [TEXT]: blk_381c53320af5491ffdc8e0b2316b9220

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/-AVusz2rmcrNS3bo7Bn7)

Синтетический комплект ar_v2_08.
Лист АР-02: текст проекта.
Примечание: высота этажа 2 равна 3,60 м.
Примечание к кровле: парапет 800 мм.
