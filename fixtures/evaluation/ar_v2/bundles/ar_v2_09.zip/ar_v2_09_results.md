# Document: ar_v2_09.pdf

Path: Синтетический набор / [АР] Архитектурные решения / ar_v2_09

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_5fd1bd842b9a2124ca0076bd6cf77dfd

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/_-SjkoaO4xNmkCrjZxr6)

Синтетический комплект ar_v2_09.
Лист АР-01: текст проекта.
Ведомость: ширина двери Д-01 равна 900 мм.
Реестр комплекта: лист АР-99 План кровли включен.

## Page 2

### BLOCK #2 [TEXT]: blk_7ccba4d21096dad58ecae64ef162d3b1

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/RBmDFPJ_23XxQmR-xhHa)

Синтетический комплект ar_v2_09.
Лист АР-02: текст проекта.
Выноска: ширина двери Д-01 равна 800 мм.
