# Document: ar_v2_07.pdf

Path: Синтетический набор / [АР] Архитектурные решения / ar_v2_07

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_b82de3f27aa19ccf71d91d9ac1e739f4

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/IfzwM81DzwKC7R57N2X8)

Синтетический комплект ar_v2_07.
Лист АР-01: текст проекта.
План: длина помещения 201 равна 4,20 м.
План кровли: воронок 4 штуки.
Реестр содержит листы АР-01 и АР-02.

## Page 2

### BLOCK #2 [TEXT]: blk_3d73318917c542cc12adf436fa5fb8a8

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/GXF7fmuYCZsZ4InziE7k)

Синтетический комплект ar_v2_07.
Лист АР-02: текст проекта.
Ведомость: длина помещения 201 равна 4,80 м.
Ведомость кровли: воронок 6 штук.
