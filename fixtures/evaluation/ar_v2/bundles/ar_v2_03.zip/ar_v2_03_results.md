# Document: ar_v2_03.pdf

Path: Синтетический набор / [АР] Архитектурные решения / ar_v2_03

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_e98fe3bf981831e37b8a872d10a60169

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/riHD9UEqdXrZF5mkkFHl)

Синтетический комплект ar_v2_03.
Лист АР-01: текст проекта.
Таблица помещений: номер 102, кухня.
Фасад северный: облицовка кирпич.
Длина стены 3,00 м равна 3000 мм.

## Page 2

### BLOCK #2 [TEXT]: blk_1b1eaee61ef23d621e4db9fb197ea8d5

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/cK6fr_l7P2mli1gkgyvv)

Синтетический комплект ar_v2_03.
Лист АР-02: текст проекта.
Экспликация: номер 102, спальня.
Примечание к северному фасаду: облицовка штукатурка.
