# Document: ar_v2_10.pdf

Path: Синтетический набор / [АР] Архитектурные решения / ar_v2_10

Generated: 2026-07-24 07:45:12 UTC

---

## Page 1

### BLOCK #1 [TEXT]: blk_b7bb4682dd7b0aebd492d40421d9fa32

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/qZkPBqgeN3a-VahTbYCw)

Синтетический комплект ar_v2_10.
Лист АР-01: текст проекта.
Легенда плана: помещение 301 граничит с коридором.
Оглавление: раздел 4 Ведомость отделки включен.

## Page 2

### BLOCK #2 [TEXT]: blk_603fb31ea10e812cb71a6958c9c2be02

> **Created:** 2026-07-07 07:36:38 UTC
> **Crop:** [Crop](https://portal.invalid/api/crops/oMgvq2k1ZMbc-LEE-Ae7)

Синтетический комплект ar_v2_10.
Лист АР-02: текст проекта.
Примечание к плану: помещение 301 граничит с кладовой.
